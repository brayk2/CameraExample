//
//  ViewController.m
//  CameraExmple
//
//  Created by Brayden Kness on 9/9/15.
//  Copyright (c) 2015 Brayden Kness. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize cameraView, captureSession, stillImageOutput, previewLayer;

- (void)viewDidLoad {
	[super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
	[super didReceiveMemoryWarning];
	// Dispose of any resources that can be recreated.
}

- (void)viewDidAppear:(BOOL)animated {
	[super viewDidAppear:animated];
	
	previewLayer.frame = cameraView.bounds;
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	captureSession = [[AVCaptureSession alloc] init];
	captureSession.sessionPreset = AVCaptureSessionPreset1920x1080;
	
	AVCaptureDevice *backCamera = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
	
	NSError *error;
	AVCaptureDeviceInput *input = [[AVCaptureDeviceInput alloc] initWithDevice:backCamera error:&error];
	
	if (error == nil && [captureSession canAddInput:input]) {
		[captureSession addInput:input];
		
		stillImageOutput = [[AVCaptureStillImageOutput alloc] init];
		stillImageOutput.outputSettings = @{AVVideoCodecKey : AVVideoCodecJPEG};
		
		if ([captureSession canAddOutput:stillImageOutput]) {
			[captureSession addOutput:stillImageOutput];
			
			previewLayer = [[AVCaptureVideoPreviewLayer alloc] initWithSession:captureSession];
			previewLayer.videoGravity = AVLayerVideoGravityResizeAspect;
			previewLayer.connection.videoOrientation = AVCaptureVideoOrientationPortrait;
			[cameraView.layer insertSublayer:previewLayer atIndex:0];
			[captureSession startRunning];
		}
	}
}

- (IBAction)takePhoto:(UIButton *)sender {
	
	AVCaptureConnection *videoConnection = [stillImageOutput connectionWithMediaType:AVMediaTypeVideo];
	
	if (videoConnection != nil) {
		
		videoConnection.videoOrientation = AVCaptureVideoOrientationPortrait;
		[stillImageOutput captureStillImageAsynchronouslyFromConnection:videoConnection completionHandler:^(CMSampleBufferRef imageDataSampleBuffer, NSError *error) {
			if (imageDataSampleBuffer != nil) {
				
				NSData *imageData = [AVCaptureStillImageOutput jpegStillImageNSDataRepresentation:imageDataSampleBuffer];
				struct CGDataProvider *dataProvider = CGDataProviderCreateWithCFData((CFDataRef)imageData);
				struct CGImage *cgImageRef = CGImageCreateWithJPEGDataProvider(dataProvider, nil, YES, kCGRenderingIntentDefault);
				
				UIImage *image = [[UIImage alloc] initWithCGImage:cgImageRef scale:1.0 orientation:UIImageOrientationRight];
				
				   //													 //
				  // /* Do whatever you want with the image variable */ //
				 //										               //
			}
		}];
	}
	

}

- (IBAction)loadPhotoLibrary:(UIButton *)sender {
	
	// Load Photo Library
	
}

@end
