//
//  AppDelegate.h
//  CameraExmple
//
//  Created by Brayden Kness on 9/9/15.
//  Copyright (c) 2015 Brayden Kness. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

