//
//  ViewController.h
//  CameraExmple
//
//  Created by Brayden Kness on 9/9/15.
//  Copyright (c) 2015 Brayden Kness. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@interface ViewController : UIViewController <UIImagePickerControllerDelegate>

@property (strong, nonatomic) IBOutlet UIView *cameraView;

@property (strong, nonatomic) AVCaptureSession *captureSession;
@property (strong, nonatomic) AVCaptureStillImageOutput *stillImageOutput;
@property (strong, nonatomic) AVCaptureVideoPreviewLayer *previewLayer;

- (IBAction)takePhoto:(UIButton *)sender;
- (IBAction)loadPhotoLibrary:(UIButton *)sender;

@end

